# Descrição do Projeto

O código usa uma API para ver quem foi o autor do último commit no repositório dev-aberto.